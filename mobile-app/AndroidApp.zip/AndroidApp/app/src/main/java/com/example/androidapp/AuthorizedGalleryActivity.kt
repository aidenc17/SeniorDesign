package com.example.androidapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.androidapp.databinding.ActivityGalleryBinding
import kotlinx.coroutines.launch

/**
 * AUTHORIZED GALLERY PAGE - Requires biometric authentication
 *
 * CUSTOMIZE:
 * - Default URL: Edit ConfigManager.kt (DEFAULT_AUTHORIZED_URL)
 * - Runtime URL: Use Settings button on this page
 * - Grid columns: Change GRID_COLUMNS below
 * - Disable biometric: Remove checkBiometric() call in onCreate
 */
class AuthorizedGalleryActivity : AppCompatActivity() {

    // ========== CUSTOMIZE THIS ==========
    private val GRID_COLUMNS = 3  // Change number of columns (2, 3, 4, etc.)
    // ====================================

    private lateinit var binding: ActivityGalleryBinding
    private lateinit var biometricHelper: BiometricHelper
    private lateinit var configManager: ConfigManager
    private val media = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        configManager = ConfigManager(this)
        biometricHelper = BiometricHelper(this)

        // Check biometric first
        checkBiometric()
    }

    // Check biometric authentication
    private fun checkBiometric() {
        if (biometricHelper.isBiometricAvailable() != BiometricHelper.BiometricStatus.AVAILABLE) {
            Toast.makeText(this, "Biometric not available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Show biometric prompt
        biometricHelper.authenticate(
            title = "Authentication Required",
            subtitle = "Use fingerprint to access authorized gallery",
            negativeButtonText = "Cancel",
            onSuccess = { setupGallery() },
            onError = { error ->
                Toast.makeText(this, "Error: $error", Toast.LENGTH_LONG).show()
                finish()
            },
            onFailed = {
                Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Setup gallery after authentication
    private fun setupGallery() {
        binding.headerLayout.visibility = View.VISIBLE
        // binding.headerTitle.text = getString(R.string.btn_authorized_gallery)
        binding.btnSettings.setOnClickListener { 
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        val adapter = PhotoAdapter { url -> openMedia(url) }
        binding.recyclerView.layoutManager = GridLayoutManager(this, GRID_COLUMNS)
        binding.recyclerView.adapter = adapter
        
        binding.swipeRefresh.setOnRefreshListener { loadMedia(adapter) }
        loadMedia(adapter)
    }
    
    // Load media from nginx
    private fun loadMedia(adapter: PhotoAdapter) {
        binding.swipeRefresh.isRefreshing = true
        
        lifecycleScope.launch {
            val service = NetworkModule.provideNginxApiService()
            val url = configManager.getAuthorizedUrl()  // Get URL from settings
            val media = service.fetchMediaUrls(url)
            
            this@AuthorizedGalleryActivity.media.clear()
            this@AuthorizedGalleryActivity.media.addAll(media)
            adapter.submitList(this@AuthorizedGalleryActivity.media)
            
            binding.swipeRefresh.isRefreshing = false
        }
    }
    
    // Open full screen image or video
    private fun openMedia(url: String) {
        if (url.endsWith(".mp4")) {
            val intent = Intent(this, VideoDetailActivity::class.java)
            intent.putExtra(VideoDetailActivity.EXTRA_VIDEO_URL, url)
            startActivity(intent)
        } else {
            val intent = Intent(this, ImageDetailActivity::class.java)
            intent.putExtra(ImageDetailActivity.EXTRA_IMAGE_URL, url)
            startActivity(intent)
        }
    }
}
