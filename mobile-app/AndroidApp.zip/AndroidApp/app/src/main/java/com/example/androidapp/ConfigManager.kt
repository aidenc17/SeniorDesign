package com.example.androidapp

import android.content.Context
import android.content.SharedPreferences

/**
 * ConfigManager - Manages app configuration and settings
 * 
 * This class handles:
 * - Storing and retrieving endpoint URLs
 * - Validating URLs
 * - Providing default URLs if none are saved
 * 
 * TO CUSTOMIZE:
 * - Default URLs: Change DEFAULT_REGULAR_URL and DEFAULT_AUTHORIZED_URL below
 * - Add new settings: Add new get/set functions and keys
 */
class ConfigManager(context: Context) {
    
    // SharedPreferences - Android's way of storing simple key-value data persistently
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    companion object {
        // Name of the preferences file
        private const val PREFS_NAME = "gallery_prefs"
        
        // Keys for storing URLs in SharedPreferences
        private const val KEY_REGULAR_URL = "regular_url"
        private const val KEY_AUTHORIZED_URL = "authorized_url"
        
        // DEFAULT ENDPOINT URLs - CHANGE THESE to update default nginx endpoints
        // These are used if user hasn't configured custom URLs in settings
        const val DEFAULT_REGULAR_URL = "http://192.168.50.233:8080/"      // Regular gallery endpoint
        const val DEFAULT_AUTHORIZED_URL = "http://192.168.50.233:8081/"   // Authorized gallery endpoint
    }
    
    /**
     * getRegularUrl - Get the regular gallery endpoint URL
     * Returns saved URL from settings, or DEFAULT_REGULAR_URL if not set
     */
    fun getRegularUrl(): String {
        return prefs.getString(KEY_REGULAR_URL, DEFAULT_REGULAR_URL) ?: DEFAULT_REGULAR_URL
    }
    
    /**
     * getAuthorizedUrl - Get the authorized gallery endpoint URL
     * Returns saved URL from settings, or DEFAULT_AUTHORIZED_URL if not set
     */
    fun getAuthorizedUrl(): String {
        return prefs.getString(KEY_AUTHORIZED_URL, DEFAULT_AUTHORIZED_URL) ?: DEFAULT_AUTHORIZED_URL
    }
    
    /**
     * setRegularUrl - Save a new regular gallery URL to settings
     * Called from SettingsActivity when user saves new URL
     */
    fun setRegularUrl(url: String) {
        prefs.edit().putString(KEY_REGULAR_URL, url).apply()
    }
    
    /**
     * setAuthorizedUrl - Save a new authorized gallery URL to settings
     * Called from SettingsActivity when user saves new URL
     */
    fun setAuthorizedUrl(url: String) {
        prefs.edit().putString(KEY_AUTHORIZED_URL, url).apply()
    }
    
    /**
     * isValidUrl - Check if a URL is valid
     * 
     * Validates that URL:
     * - Is not blank
     * - Starts with http:// or https://
     * - Has valid domain/IP format
     * - Optionally includes port number and path
     * 
     * TO CUSTOMIZE:
     * - Change validation rules: Modify the urlPattern regex below
     * - Allow only HTTPS: Change "https?" to "https" in regex
     */
    fun isValidUrl(url: String): Boolean {
        if (url.isBlank()) return false
        
        // Regex pattern for URL validation
        // ^https? = starts with http or https
        // [\w.-]+ = domain name or IP address
        // (:[0-9]+)? = optional port number (e.g., :8080)
        // (/.*)?$ = optional path (e.g., /images/)
        val urlPattern = Regex("^https?://[\\w.-]+(:[0-9]+)?(/.*)?$")
        return urlPattern.matches(url)
    }
}
