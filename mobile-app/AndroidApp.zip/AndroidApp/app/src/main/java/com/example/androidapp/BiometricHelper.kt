package com.example.androidapp

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * BiometricHelper - Handles fingerprint and face authentication
 * 
 * This class provides:
 * - Check if biometric hardware is available
 * - Prompt user for biometric authentication
 * - Handle authentication results (success, failure, error)
 *
 */
class BiometricHelper(private val activity: FragmentActivity) {
    
    /**
     * isBiometricAvailable - Check if biometric authentication is available
     * 
     * Returns BiometricStatus indicating why biometric is/isn't available:
     * - AVAILABLE: Device has biometric and user has enrolled
     * - NO_HARDWARE: Device doesn't have fingerprint/face sensor
     * - UNAVAILABLE: Hardware exists but currently unavailable
     * - NOT_ENROLLED: User hasn't set up fingerprint/face on device
     * - UNKNOWN_ERROR: Other error occurred
     */
    fun isBiometricAvailable(): BiometricStatus {
        val biometricManager = BiometricManager.from(activity)
        
        // Check biometric availability
        // BIOMETRIC_STRONG = fingerprint, iris, face (most secure)
        // BIOMETRIC_WEAK = less secure face recognition
        return when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricStatus.AVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricStatus.NO_HARDWARE
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> BiometricStatus.UNAVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricStatus.NOT_ENROLLED
            else -> BiometricStatus.UNKNOWN_ERROR
        }
    }
    
    /**
     * authenticate - Show biometric authentication prompt
     * 
     * @param title Dialog title (e.g., "Authentication Required")
     * @param subtitle Dialog subtitle (e.g., "Use fingerprint to continue")
     * @param negativeButtonText Cancel button text (e.g., "Cancel")
     * @param onSuccess Callback when authentication succeeds
     * @param onError Callback when error occurs (e.g., sensor unavailable)
     * @param onFailed Callback when authentication fails (wrong fingerprint/face)
     */
    fun authenticate(
        title: String,
        subtitle: String,
        negativeButtonText: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit,
        onFailed: () -> Unit
    ) {
        // Executor runs callbacks on main UI thread
        val executor = ContextCompat.getMainExecutor(activity)
        
        // Create BiometricPrompt with authentication callbacks
        val biometricPrompt = BiometricPrompt(activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                // Called when authentication error occurs (sensor unavailable, user cancelled, etc.)
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onError(errString.toString())
                }
                
                // Called when fingerprint/face matches successfully
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }
                
                // Called when fingerprint/face doesn't match (can retry)
                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onFailed()
                }
            })
        
        // Build the authentication prompt dialog
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)                           // Main title
            .setSubtitle(subtitle)                      // Subtitle/description
            .setNegativeButtonText(negativeButtonText)  // Cancel button
            .build()
        
        // Show the biometric authentication dialog
        biometricPrompt.authenticate(promptInfo)
    }
    
    /**
     * BiometricStatus - Enum representing biometric availability status
     */
    enum class BiometricStatus {
        AVAILABLE,       // Biometric is available and ready to use
        NO_HARDWARE,     // Device has no biometric sensor
        UNAVAILABLE,     // Sensor exists but currently unavailable
        NOT_ENROLLED,    // User hasn't enrolled biometric on device
        UNKNOWN_ERROR    // Other error occurred
    }
}
