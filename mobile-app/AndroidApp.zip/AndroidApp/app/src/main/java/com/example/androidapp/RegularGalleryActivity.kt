package com.example.androidapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.androidapp.databinding.ActivityGalleryBinding
import kotlinx.coroutines.launch

/**
 * REGULAR GALLERY PAGE - For public access
 * 
 * CUSTOMIZE:
 * - Default URL: Edit ConfigManager.kt (DEFAULT_REGULAR_URL)
 * - Runtime URL: Use Settings button in main page
 * - Grid columns: Change gridColumns below
 */
class RegularGalleryActivity : AppCompatActivity() {
    
    // ========== CUSTOMIZE THIS ==========
    private val gridColumns = 3  // Change number of columns (2, 3, 4, etc.)
    // ====================================
    
    private lateinit var binding: ActivityGalleryBinding
    private lateinit var configManager: ConfigManager
    private val media = mutableListOf<String>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        
        configManager = ConfigManager(this)
        
        // Setup header
        binding.headerLayout.visibility = View.VISIBLE
        binding.headerTitle.text = getString(R.string.btn_regular_gallery)
        binding.btnSettings.visibility = View.GONE // No settings for regular gallery
        
        // Setup grid
        val adapter = PhotoAdapter { url -> openMedia(url) }
        binding.recyclerView.layoutManager = GridLayoutManager(this, gridColumns)
        binding.recyclerView.adapter = adapter
        
        // Pull to refresh
        binding.swipeRefresh.setOnRefreshListener { loadMedia(adapter) }
        
        // Load media
        loadMedia(adapter)
    }
    
    // Load media from nginx
    private fun loadMedia(adapter: PhotoAdapter) {
        binding.swipeRefresh.isRefreshing = true
        
        lifecycleScope.launch {
            val service = NetworkModule.provideNginxApiService()
            val url = configManager.getRegularUrl()  // Get URL from settings
            val media = service.fetchMediaUrls(url)
            
            this@RegularGalleryActivity.media.clear()
            this@RegularGalleryActivity.media.addAll(media)
            adapter.submitList(this@RegularGalleryActivity.media)
            
            binding.swipeRefresh.isRefreshing = false
        }
    }
    
    // Open full screen image or video
    private fun openMedia(url: String) {
        if (url.endsWith(".mp4")) {
            val intent = Intent(this, VideoDetailActivity::class.java)
            intent.putExtra(VideoDetailActivity.EXTRA_VIDEO_URL, url)
            startActivity(intent)
        } else {
            val intent = Intent(this, ImageDetailActivity::class.java)
            intent.putExtra(ImageDetailActivity.EXTRA_IMAGE_URL, url)
            startActivity(intent)
        }
    }
}
