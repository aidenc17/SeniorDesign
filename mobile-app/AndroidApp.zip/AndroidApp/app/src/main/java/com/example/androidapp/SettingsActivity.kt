package com.example.androidapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.androidapp.databinding.ActivitySettingsBinding

/**
 * SETTINGS PAGE - Configure gallery URLs
 * 
 * NOTE: With the new simplified design, you can just edit URLs
 * directly in RegularGalleryActivity.kt and AuthorizedGalleryActivity.kt
 * This settings page is optional.
 */
class SettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var configManager: ConfigManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        configManager = ConfigManager(this)
        
        // Load saved URLs (or defaults)
        binding.editRegularUrl.setText(configManager.getRegularUrl())
        binding.editAuthorizedUrl.setText(configManager.getAuthorizedUrl())
        
        // Save button
        binding.btnSave.setOnClickListener { saveSettings() }
    }
    
    private fun saveSettings() {
        val regularUrl = binding.editRegularUrl.text.toString().trim()
        val authorizedUrl = binding.editAuthorizedUrl.text.toString().trim()
        
        // Validate URLs
        if (!configManager.isValidUrl(regularUrl)) {
            binding.editRegularUrl.error = getString(R.string.invalid_url)
            return
        }
        
        if (!configManager.isValidUrl(authorizedUrl)) {
            binding.editAuthorizedUrl.error = getString(R.string.invalid_url)
            return
        }
        
        // Save URLs
        configManager.setRegularUrl(regularUrl)
        configManager.setAuthorizedUrl(authorizedUrl)
        
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        finish()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
