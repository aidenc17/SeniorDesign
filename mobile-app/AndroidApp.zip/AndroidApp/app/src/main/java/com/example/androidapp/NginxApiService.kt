package com.example.androidapp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup

class NginxApiService(private val client: OkHttpClient) {
    
    suspend fun fetchMediaUrls(baseUrl: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(baseUrl)
                .build()
            
            val response = client.newCall(request).execute()
            
            if (!response.isSuccessful) {
                return@withContext emptyList()
            }
            
            val html = response.body?.string() ?: return@withContext emptyList()
            
            // Parse nginx directory listing HTML
            val document = Jsoup.parse(html)
            val links = document.select("a[href]")
            
            val mediaUrls = mutableListOf<String>()
            
            links.forEach { link ->
                val href = link.attr("href")
                
                // Filter for media files
                if (isMediaFile(href)) {
                    val fullUrl = if (href.startsWith("http")) {
                        href
                    } else {
                        // Construct full URL
                        val cleanBase = baseUrl.trimEnd('/')
                        val cleanHref = href.trimStart('/')
                        "$cleanBase/$cleanHref"
                    }
                    mediaUrls.add(fullUrl)
                }
            }
            
            mediaUrls
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
    
    private fun isMediaFile(filename: String): Boolean {
        val mediaExtensions = listOf(".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".mp4")
        val lowerFilename = filename.lowercase()
        return mediaExtensions.any { lowerFilename.endsWith(it) }
    }
}
