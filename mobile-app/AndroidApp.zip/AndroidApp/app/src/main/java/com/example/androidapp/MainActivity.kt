package com.example.androidapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.androidapp.databinding.ActivityMainBinding

/**
 * MAIN PAGE - Choose which gallery to open
 * 
 * CUSTOMIZE:
 * - App title: Edit res/values/strings.xml (welcome_title)
 * - Button text: Edit res/values/strings.xml (btn_regular_gallery, btn_authorized_gallery)
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Button clicks
        binding.btnRegularGallery.setOnClickListener { openRegularGallery() }
        binding.btnAuthorizedGallery.setOnClickListener { openAuthorizedGallery() }
    }
    
    // Open regular gallery (no authentication)
    private fun openRegularGallery() {
        startActivity(Intent(this, RegularGalleryActivity::class.java))
    }
    
    // Open authorized gallery (requires biometric)
    private fun openAuthorizedGallery() {
        startActivity(Intent(this, AuthorizedGalleryActivity::class.java))
    }
}
