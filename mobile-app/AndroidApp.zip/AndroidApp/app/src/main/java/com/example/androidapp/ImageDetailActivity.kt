package com.example.androidapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.androidapp.databinding.ActivityImageDetailBinding

/**
 * FULL SCREEN IMAGE PAGE - View image with zoom
 */
class ImageDetailActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityImageDetailBinding
    
    companion object {
        const val EXTRA_IMAGE_URL = "extra_image_url"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Get image URL from intent
        val imageUrl = intent.getStringExtra(EXTRA_IMAGE_URL) ?: ""
        
        // Load image with Glide
        Glide.with(this)
            .load(imageUrl)
            .error(android.R.drawable.ic_menu_report_image)
            .into(binding.photoView)
        
        // Close button
        binding.btnClose.setOnClickListener { finish() }
    }
}
