package com.example.androidapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.androidapp.databinding.ItemPhotoBinding
import com.example.androidapp.databinding.ItemVideoBinding

private const val VIEW_TYPE_IMAGE = 0
private const val VIEW_TYPE_VIDEO = 1

/**
 * PhotoAdapter - Displays photos and videos in a grid
 */
class PhotoAdapter(
    private val onPhotoClick: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<String>()

    fun submitList(newItems: List<String>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].endsWith(".mp4")) VIEW_TYPE_VIDEO else VIEW_TYPE_IMAGE
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_IMAGE) {
            val binding = ItemPhotoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            PhotoViewHolder(binding)
        } else {
            val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            VideoViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == VIEW_TYPE_IMAGE) {
            (holder as PhotoViewHolder).bind(items[position])
        } else {
            (holder as VideoViewHolder).bind(items[position])
        }
    }

    override fun getItemCount(): Int = items.size

    inner class PhotoViewHolder(private val binding: ItemPhotoBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(photoUrl: String) {
            Glide.with(binding.imageView)
                .load(photoUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(binding.imageView)

            binding.root.setOnClickListener {
                onPhotoClick(photoUrl)
            }
        }
    }

    inner class VideoViewHolder(private val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(videoUrl: String) {
            Glide.with(binding.videoThumbnail.context)
                .load(videoUrl)
                .frame(1000000) // 1,000,000 microseconds = 1 second
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(binding.videoThumbnail)

            binding.root.setOnClickListener {
                onPhotoClick(videoUrl)
            }
        }
    }
}
