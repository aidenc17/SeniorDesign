# Android Photo Gallery App - Customization Guide

This guide shows you exactly where to make common changes to customize the app.

## Changing App Name and Titles

**File:** `app/src/main/res/values/strings.xml`

```xml
<string name="app_name">Photo Gallery</string>          <!-- App name in launcher -->
<string name="welcome_title">Photo Gallery</string>     <!-- Main screen title -->
<string name="welcome_message">Choose a gallery to view</string>  <!-- Main screen subtitle -->
```

**To change:** Edit the text between `>` and `</string>`

---

## Changing Default Endpoint URLs

**File:** `app/src/main/java/com/example/androidapp/ConfigManager.kt`

Look for lines 33-34:

```kotlin
const val DEFAULT_REGULAR_URL = "http://192.168.50.233:8080/"      // Regular gallery endpoint
const val DEFAULT_AUTHORIZED_URL = "http://192.168.50.233:8081/"   // Authorized gallery endpoint
```

**To change:** Replace the URLs with your nginx server addresses

---

## Changing Button Text

**File:** `app/src/main/res/values/strings.xml`

```xml
<string name="btn_regular_gallery">Regular Gallery</string>
<string name="btn_authorized_gallery">Authorized Gallery</string>
<string name="settings">Settings</string>
```

---

## Disabling Biometric Authentication

**Option 1 - Skip biometric entirely:**

**File:** `app/src/main/java/com/example/androidapp/MainActivity.kt`

Find line 73-75:
```kotlin
binding.btnAuthorizedGallery.setOnClickListener {
    authenticateForAuthorizedGallery()  // <- Change this line
}
```

Change to:
```kotlin
binding.btnAuthorizedGallery.setOnClickListener {
    openGallery(configManager.getAuthorizedUrl())  // Direct access without biometric
}
```

---

## Changing Colors

**File:** `app/src/main/res/values/colors.xml`

The primary colors are `purple_500`, `purple_700` and `teal_200`. You can also add your own.

```xml
<color name="purple_500">#FF6200EE</color>  <!-- Primary color -->
<color name="purple_700">#FF3700B3</color>  <!-- Primary dark color -->
<color name="teal_200">#FF03DAC5</color>    <!-- Accent color -->
<color name="WSUGreen">#FF046A38</color>
<color name="WSUGold">#CBA052</color>
```

Change the hex color codes (e.g., `#FF6200EE`) to your preferred colors.

---

## Changing Grid Columns

**File:** `app/src/main/java/com/example/androidapp/GalleryActivity.kt`

Find line 46:
```kotlin
layoutManager = GridLayoutManager(this@GalleryActivity, 3)  // 3 columns
```

Change `3` to `2` for 2 columns, or `4` for 4 columns, etc.

---

## Adding Support for More Image Types

**File:** `app/src/main/java/com/example/androidapp/NginxApiService.kt`

Find line 56:
```kotlin
val imageExtensions = listOf(".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp")
```

Add more extensions to the list:
```kotlin
val imageExtensions = listOf(".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".tiff")
```

---

## Changing Network Timeout

**File:** `app/src/main/java/com/example/androidapp/NetworkModule.kt`

Find lines 19-21:
```kotlin
.connectTimeout(30, TimeUnit.SECONDS)  // Connection timeout
.readTimeout(30, TimeUnit.SECONDS)     // Read timeout
.writeTimeout(30, TimeUnit.SECONDS)    // Write timeout
```

Change `30` to your desired timeout in seconds.

---

##  Changing Network Security (Allowing Different IPs)

**File:** `app/src/main/res/xml/network_security_config.xml`

```xml
<domain includeSubdomains="true">192.168.50.233</domain>
```

Add more domains/IPs:
```xml
<domain includeSubdomains="true">192.168.50.233</domain>
<domain includeSubdomains="true">192.168.1.100</domain>
<domain includeSubdomains="true">myserver.local</domain>
```

---

##  Changing Biometric Prompt Text

**File:** `app/src/main/res/values/strings.xml`

```xml
<string name="biometric_title">Authentication Required</string>
<string name="biometric_subtitle">Authenticate to access authorized gallery</string>
<string name="biometric_description">Use your fingerprint or face to authenticate</string>
```

---

##  Key Files Reference

### Main Code Files (*.kt)
- `MainActivity.kt` - Main screen with two gallery buttons
- `ConfigManager.kt` - **DEFAULT URLS ARE HERE** (lines 33-34)
- `BiometricHelper.kt` - Biometric authentication logic
- `SettingsActivity.kt` - Settings screen for configuring URLs
- `GalleryActivity.kt` - Grid view of images
- `ImageDetailActivity.kt` - Full-screen image viewer
- `NginxApiService.kt` - Fetches images from nginx
- `PhotoAdapter.kt` - Handles displaying images in grid

### Layout Files (*.xml)
- `res/layout/activity_main.xml` - Main screen layout
- `res/layout/activity_settings.xml` - Settings screen layout
- `res/layout/activity_gallery.xml` - Gallery grid layout
- `res/layout/activity_image_detail.xml` - Full-screen image layout
- `res/layout/item_photo.xml` - Single grid item layout

### Resource Files
- `res/values/strings.xml` - **ALL TEXT IS HERE** (app name, button labels, messages)
- `res/values/colors.xml` - App colors
- `res/values/themes.xml` - App theme
- `res/xml/network_security_config.xml` - Network security settings

### Configuration Files
- `app/build.gradle` - Dependencies and build settings
- `gradle.properties` - Gradle configuration

---

##  Quick Customization Checklist

Use this checklist for common customizations:

- [ ] Change app name: Edit `strings.xml` → `app_name`
- [ ] Change default URLs: Edit `ConfigManager.kt` → lines 33-34
- [ ] Change button text: Edit `strings.xml` → `btn_regular_gallery`, `btn_authorized_gallery`
- [ ] Change grid columns: Edit `GalleryActivity.kt` → line 46
- [ ] Change colors: Edit `colors.xml`
- [ ] Disable biometric: Edit `MainActivity.kt` → line 75

---

##  Tips

1. **After changing code:** Click "Sync Project with Gradle Files" in Android Studio
2. **After changing strings/layouts:** Rebuild the app (Build → Rebuild Project)
3. **To test changes:** Run the app on emulator or device
4. **Backup before major changes:** Commit to git or copy the project folder

---

##  File Locations Summary

All files are relative to: `C:\Users\Tom\Documents\AndroidApp\`

- Java/Kotlin code: `app/src/main/java/com/example/androidapp/`
- Layouts: `app/src/main/res/layout/`
- Strings: `app/src/main/res/values/strings.xml`
- Colors: `app/src/main/res/values/colors.xml`
